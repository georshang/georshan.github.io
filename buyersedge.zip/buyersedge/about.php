<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer's Edge | About us</title>
    <link rel="stylesheet" href="styles/about.css">
</head>
<body>
    <?php include('header.php'); ?>
    <h1>Sorry! This Page is Under Production :) <h1>
</body>
</html>