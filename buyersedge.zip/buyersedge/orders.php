<?php
include("include/connection.php");

$userID = $_COOKIE['userID'];

if(isset($userID))
{
    $getUser = "select * from users where user_id='$userID'";
    $runUser = mysqli_query($con, $getUser);
    $row = mysqli_fetch_array($runUser);
    
    $userName = $row['user_name'];


    $getOrdersQuery = "select * from orders where user_id='$userID'";
    $runOrdersQuery = mysqli_query($con, $getOrdersQuery);
    $ordersCount = mysqli_num_rows($runOrdersQuery);
   
}
else {
    echo"<script>window.open('login.php', '_self')</script>";
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php echo"$userName"; ?></title>
    <link rel="stylesheet" href="styles/profile.css">
    <link rel="stylesheet" href="styles/basic.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>

<body>
    <div class="wrapper">
    <?php 
			include 'header.php'; 
	?>

        <div class='orders-area'>
            <h1 id='title'> Orders</h1>
            <div class='orders'>
                <?php
                if($ordersCount > 0) 
                {
                    while($rowOrders = mysqli_fetch_array($runOrdersQuery)) {
                    $productID = $rowOrders['product_id'];
                    $orderID = $rowOrders['order_id'];
                    $orderDateTime = $rowOrders['order_date'];

                    $orderDateTimepieces = explode(" ", $orderDateTime);

                    $getProductQuery = "select * from products where product_id='$productID'";
                    $runGetProductQuery = mysqli_query($con, $getProductQuery);
                    $rowProduct = mysqli_fetch_array($runGetProductQuery);
                    
                    $productName = $rowProduct['product_name'];
                    $productImage = $rowProduct['product_image'];

                    echo"
                   
                        <div class='section' onclick=location.href='view-order.php?order_id=$orderID'>
                            <img src='storage/products/$productImage'>
                            <p id='name'> $productName </p>
                            <p id='id'> #$orderID </p>
                            <p id='date'> $orderDateTimepieces[0] </p>
                        </div>
                     
                    ";
                }
                } else {
                echo"
                    <p id='emptyOrders'> No Orders</p>
                ";
                }
                ?>
            </div>
        </div>

    </div>

    <?php 
			include 'footer.php'; 
	?>

    <script src="jquery/jquery-3.5.1.min.js"></script>
    <script src="scripts/profile.js"></script>

</body>

</html>