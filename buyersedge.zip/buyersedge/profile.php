<?php
include("include/connection.php");

$userID = $_COOKIE['userID'];

if(isset($userID))
{
    $getUser = "select * from users where user_id='$userID'";
    $runUser = mysqli_query($con, $getUser);
    $row = mysqli_fetch_array($runUser);
    
    $userEmail = $row['user_email'];
    $userName = $row['user_name'];
    $userImage = $row['user_image'];
    $userAddress = $row['user_address'];
    $userPhone = $row['user_phone'];
    $userRole = $row['user_role'];


    $getOrdersQuery = "select * from orders where user_id='$userID'";
    $runOrdersQuery = mysqli_query($con, $getOrdersQuery);
    $ordersCount = mysqli_num_rows($runOrdersQuery);
   
}
else {
    echo"<script>window.open('home.php', '_self')</script>";
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php echo"$userName"; ?></title>
    <link rel="stylesheet" href="styles/profile.css">
    <link rel="stylesheet" href="styles/basic.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="wrapper">

    <?php 
			include 'header.php'; 
	    ?>

        <div class="profile-area">
            <h1 id="title"> Profile</h1>
            <div class="section-one">
                <div class="left">
                    <?php 
                    if(empty($userImage)) {
                        echo" <img src='images/user.png' alt=''>";
                    } else {
                        echo" <img src='storage/users/$userImage' alt=''>";
                    }
                    ?>

                </div>
                <div class="right">
                    <?php
                    echo"
                    <h1> $userName<h1>
                    <h3> $userEmail <h3>
                    "; 
                    ?>
                </div>
            </div>
            <div class="section-two">
                <?php
                if(empty($userAddress)) {
                    echo"<p> <spin  id='left'>Address:</spin> none </p>";
                } else {
                    echo"<p>  <spin  id='left'>Address:</spin> $userAddress </p>";
                }

                if(empty($userPhone)) {
                    echo"<p> <spin  id='left'>Phone:</spin> none </p>";
                } else {
                    echo"<p>  <spin  id='left'>Phone:</spin> $userPhone </p>";
                }
                ?>

            </div>
            <div class="button-container">
                <button id="editProfileBtn" type='button' onclick='editProfile()'> Edit Profile </button>
                <button id="logoutBtn" type='button' onclick='userLogout()'> Logout </button>
            </div>
            <?php 
                    if($userRole =='admin') { 
                    ?>
                        <h4>Go to Admin Panel</h4>
                        <button id="admin" type='button' onclick='admin()'>Admin Panel</button>
                    <?php }
                    elseif($userRole =='seller') { 
                        ?>
                            <h4>Go to Panel</h4>
                            <button id="admin" type='button' onclick='admin()'>Panel</button>
                        <?php }
                ?>
        </div>
    </div>

    <?php 
			include 'footer.php'; 
	    ?>

    <script src="jquery/jquery-3.5.1.min.js"></script>
    <script src="scripts/profile.js"></script>

</body>

</html>