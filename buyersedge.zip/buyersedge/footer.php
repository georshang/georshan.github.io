<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer's Edge | Home</title>
    <link rel="stylesheet" href="styles/basic.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>
<body>
    <div class="footer-container">
        <div class="footer">
            <div class="designer">
                <h1>Designed by Ponjeslians</h1>
            </div>
            <p>Copyright ©2022 iMart By Ponjeslians All rights reserved.</p>
        </div>
    </div>
</body>