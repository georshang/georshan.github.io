<div class="container">
        <?php include('sidebar.php')?>
        <div class="orders-container">
            <?php 
            if ( $data == 0 ) 
            { 
                if($userRole == 'admin' || $userRole == 'seller')
                { ?>
                        <div>
                            <h1> Your Product Orders</h1>
                            <?php
                                while($rowOrder = mysqli_fetch_array($runOrdersQuery)) {
                                    $orderID = $rowOrder['order_id'];
                                    $productID = $rowOrder['product_id'];
                                    $orderDate = $rowOrder['order_date'];
                                    $orderStatus = $rowOrder['order_status'];
                                    $orderName = $rowOrder['order_name'];
                                    $orderAddress = $rowOrder['order_address'];

                                    echo"
                                    <div class='order'>
                                    <h2>#$orderID </h2>
                                        <div class='main'>
                                            <div class='order-details'>
                                                <p>Product ID: <span> $productID</span></p>
                                                <p>Order Date: <span>$orderDate</span></p>
                                                <p>Order Status: <span>$orderStatus</span></p>
                                            </div>
                                            <div class='order-user'>
                                                <p>Name: <span> $orderName</span></p>
                                                <p>Address: <span>$orderAddress</span></p>
                                            </div>
                                        </div>
                                        <div class='controller'>
                                            <button class='controller-btns' onClick='manageOrder(\"processing\",$orderID,$data)' >Accept</button>
                                            <button class='controller-btns' onClick='manageOrder(\"shipped\",$orderID,$data)'>Shipped</button>
                                            <button class='controller-btns' onClick='manageOrder(\"rejected\",$orderID,$data)'>Reject</button>
                                        </div>
                                    </div>
                                    ";
                                }
                            ?>
                        <div> <?php
                }
            } 
            elseif( $data == 1 )
            { 
                if($userRole == 'admin')
                { ?>
                    <div>
                                <h1> Other Product Orders</h1>
                                <?php
                                    while($rowOrder = mysqli_fetch_array($runOtherOrdersQuery)) {
                                        $orderID = $rowOrder['order_id'];
                                        $productID = $rowOrder['product_id'];
                                        $orderDate = $rowOrder['order_date'];
                                        $orderStatus = $rowOrder['order_status'];
                                        $orderName = $rowOrder['order_name'];
                                        $orderAddress = $rowOrder['order_address'];

                                        echo"
                                        <div class='order'>
                                        <h2>#$orderID </h2>
                                            <div class='main'>
                                                <div class='order-details'>
                                                    <p>Product ID: <span> $productID</span></p>
                                                    <p>Order Date: <span>$orderDate</span></p>
                                                    <p>Order Status: <span>$orderStatus</span></p>
                                                </div>
                                                <div class='order-user'>
                                                    <p>Name: <span> $orderName</span></p>
                                                    <p>Address: <span>$orderAddress</span></p>
                                                </div>
                                            </div>
                                            <div class='controller'>
                                                <button class='controller-btns' onClick='manageOrder(\"processing\",$orderID,$data)' >Accept</button>
                                                <button class='controller-btns' onClick='manageOrder(\"shipped\",$orderID,$data)'>Shipped</button>
                                                <button class='controller-btns' onClick='manageOrder(\"rejected\",$orderID,$data)'>Reject</button>
                                            </div>
                                        </div>
                                        ";
                                    }
                                ?>
                        </div> <?php 
                }
                else{
                    echo"<script>window.open('../dashboard.php?msg=AccessDenied!', '_self')</script>";
                } 
            }?>
        </div>

    </div>