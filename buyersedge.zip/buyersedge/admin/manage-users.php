<!DOCTYPE html>
<?php
include("../include/connection.php");

//getting users data

$userID = $_COOKIE['userID'];
$data = $_GET['data'];

unset($_POST['submit']);

?>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Manage Users </title>
        <link rel="stylesheet" href="../styles/admin-basic.css">
        <link rel="stylesheet" href="../styles/admin-manage-users.css">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
            rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

     <?php 
     if(isset($userID))
     {
         $sql = "select user_role from users where user_id='{$userID}';";
         $run_sql = mysqli_query($con, $sql);
         $row_sql = mysqli_fetch_array($run_sql);
         $userRole = $row_sql['user_role'];
     
         if($userRole != 'admin')
         {
             if($userRole != 'seller')
             {
                echo"<script>window.open('../login.php?AdminPageRestricted', '_self')</script>";
     
             }
             else
             {
                 echo"<script>window.open('../admin/dashboard.php?msg=AccessDenied!', '_self')</script>";
             }
         }
         else{ ?>
        <div class="container">
            <?php include('sidebar.php'); ?>

            <div class="users-container">
                <?php $data = $_GET['data'];
                if($data == 0 )
                { ?> 
                <div>
                    <h1><center> All Users</center></h1>
                    <?php
                    $getUsersQuery = "select * from users ";
                    $runUsersQuery = mysqli_query($con, $getUsersQuery);
                    if ($runUsersQuery->num_rows > 0) 
                        { ?>
                            <table>
                                <tr>
                                    <th>SN</th>
                                    <th>USER NAME</th>
                                    <th>USER ID</th>
                                    <th>USER EMAIL</th>
                                    <th>USER ROLE</th>
                                    <th>DELETE</th>
                                    <th>EDIT</th>
                                </tr>
                                <?php 
                                // output data of each row
                                while($rowUsers = mysqli_fetch_array($runUsersQuery)) 
                                {
                                    $sn=$sn+1;

                                    $userName = $rowUsers['user_name'];
                                    $userID = $rowUsers['user_id'];
                                    $userEmail = $rowUsers['user_email'];
                                    $userRole = $rowUsers['user_role'];
                                    $userImage = $rowUsers['user_image'];
                                ?>
                                    <tr>
                                        <td> <?php echo $sn ?> </td>
                                        <td><?php echo $userName ?></td>
                                        <td><?php echo $userID ?></td>
                                        <td><?php echo $userEmail ?></td>
                                        <td><?php echo $userRole ?></td>
                                        <td><img class='delete' src='../images/delete.png' alt='' onClick='deleteUser(\"$userID\")' title='Delete'></td>
                                        <td><a href="update_user_profile.php?userID=<?php echo $userID ?>"><i class="fa fa-edit" style="font-size:24px"></i></a></td>
                                        
                                    </tr>
                                    <?php 
                                }
                        }
                    else 
                    {
                        echo "0 results";
                    }
                        ?>
                            </table>
                
                </div>
                <?php } 
                elseif($data == 1){
                ?>
                <div>
                    <h1><center> Admins </center></h1>
                    <?php
                    $getUsersQuery = "select * from users where user_role='admin'";
                    $runUsersQuery = mysqli_query($con, $getUsersQuery);
                    if ($runUsersQuery->num_rows > 0) 
                        { ?>
                            <table>
                                <tr>
                                    <th>SN</th>
                                    <th>USER NAME</th>
                                    <th>USER ID</th>
                                    <th>USER EMAIL</th>
                                    <th>USER ROLE</th>
                                    <th>DELETE</th>
                                    <th>EDIT</th>
                                </tr>
                                <?php 
                                // output data of each row
                                while($rowUsers = mysqli_fetch_array($runUsersQuery)) 
                                {
                                    $sn=$sn+1;

                                    $userName = $rowUsers['user_name'];
                                    $userID = $rowUsers['user_id'];
                                    $userEmail = $rowUsers['user_email'];
                                    $userRole = $rowUsers['user_role'];
                                    $userImage = $rowUsers['user_image'];
                                ?>
                                    <tr>
                                        <td> <?php echo $sn ?> </td>
                                        <td><?php echo $userName ?></td>
                                        <td><?php echo $userID ?></td>
                                        <td><?php echo $userEmail ?></td>
                                        <td><?php echo $userRole ?></td>
                                        <td><img class='delete' src='../images/delete.png' alt='' onClick='deleteUser(\"$userID\")' title='Delete'></td>
                                        <td><a href="update_user_profile.php?userID=<?php echo $userID ?>"><i class="fa fa-edit" style="font-size:24px"></i></a></td>
                                        
                                    </tr>
                                    <?php 
                                }
                        }
                    else 
                    {
                        echo "0 results";
                    }
                        ?>
                            </table>
                
                </div>
                <?php } 
                elseif($data == 2){
                ?>
                <div>
                    <h1><center> Sellers</center></h1>
                    <?php
                    $getUsersQuery = "select * from users where user_role='seller'";
                    $runUsersQuery = mysqli_query($con, $getUsersQuery);
                    if ($runUsersQuery->num_rows > 0) 
                        { ?>
                            <table>
                                <tr>
                                    <th>SN</th>
                                    <th>USER NAME</th>
                                    <th>USER ID</th>
                                    <th>USER EMAIL</th>
                                    <th>USER ROLE</th>
                                    <th>DELETE</th>
                                    <th>EDIT</th>
                                </tr>
                                <?php 
                                // output data of each row
                                while($rowUsers = mysqli_fetch_array($runUsersQuery)) 
                                {
                                    $sn=$sn+1;

                                    $userName = $rowUsers['user_name'];
                                    $userID = $rowUsers['user_id'];
                                    $userEmail = $rowUsers['user_email'];
                                    $userRole = $rowUsers['user_role'];
                                    $userImage = $rowUsers['user_image'];
                                ?>
                                    <tr>
                                        <td> <?php echo $sn ?> </td>
                                        <td><?php echo $userName ?></td>
                                        <td><?php echo $userID ?></td>
                                        <td><?php echo $userEmail ?></td>
                                        <td><?php echo $userRole ?></td>
                                        <td><img class='delete' src='../images/delete.png' alt='' onClick='deleteUser(\"$userID\")' title='Delete'></td>
                                        <td><a href="update_user_profile.php?userID=<?php echo $userID ?>"><i class="fa fa-edit" style="font-size:24px"></i></a></td>
                                        
                                    </tr>
                                    <?php 
                                }
                        }
                    else 
                    {
                        echo "0 results";
                    }
                        ?>
                            </table>
                
                </div>
                <?php } 
                elseif($data == 3){
                ?>
                <div>
                    <h1><center> Customers</center></h1>
                    <?php
                    $getUsersQuery = "select * from users where user_role='normal'";
                    $runUsersQuery = mysqli_query($con, $getUsersQuery);
                    if ($runUsersQuery->num_rows > 0) 
                        { ?>
                            <table>
                                <tr>
                                    <th>SN</th>
                                    <th>USER NAME</th>
                                    <th>USER ID</th>
                                    <th>USER EMAIL</th>
                                    <th>USER ROLE</th>
                                    <th>DELETE</th>
                                    <th>EDIT</th>
                                </tr>
                                <?php 
                                // output data of each row
                                while($rowUsers = mysqli_fetch_array($runUsersQuery)) 
                                {
                                    $sn = $sn+1;

                                    $userName = $rowUsers['user_name'];
                                    $userID = $rowUsers['user_id'];
                                    $userEmail = $rowUsers['user_email'];
                                    $userRole = $rowUsers['user_role'];
                                    $userImage = $rowUsers['user_image'];
                                ?>
                                    <tr>
                                        <td> <?php echo $sn ?> </td>
                                        <td><?php echo $userName ?></td>
                                        <td><?php echo $userID ?></td>
                                        <td><?php echo $userEmail ?></td>
                                        <td><?php echo $userRole ?></td>
                                        <td><img class='delete' src='../images/delete.png' alt='' onClick='deleteUser(\"$userID\")' title='Delete'></td>
                                        <td><a href="update_user_profile.php?userID=<?php echo $userID ?>"><i class="fa fa-edit" style="font-size:24px"></i></a></td>
                                        
                                    </tr>
                                    <?php 
                                }
                        }
                    else 
                    {
                        echo "0 results";
                    }
                        ?>
                            </table>
                
                </div>
                <?php } ?>

                
            
        </div>
     <?php }
     
     }
     else {
         echo"<script>window.open('../login.php', '_self')</script>";
     }
     
     ?>   
    
    


        <script src="../jquery/jquery-3.5.1.min.js"></script>
        <script src="../scripts/admin.js"></script>
</body>

</html>