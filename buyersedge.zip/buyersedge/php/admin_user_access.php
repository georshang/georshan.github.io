<?php

include("../include/connection.php");

$userID = $_COOKIE['userID'];
$data = $_GET['data'];

if(isset($userID))
{
    $sql = "select user_role from users where user_id='{$userID}';";
    $run_sql = mysqli_query($con, $sql);
    $row_sql = mysqli_fetch_array($run_sql);
    $userRole = $row_sql['user_role'];

    if($userRole != 'admin')
    {
        if($userRole != 'seller'){
        echo"<script>window.open('../login.php?AdminPageRestricted', '_self')</script>";

        }
        else{
            echo"<script>window.open('../admin/dashboard.php?msg=AccessDenied!', '_self')</script>";
        }

    }
    else{
        echo"<script>window.open('/admin/manage-users.php?data=$data', '_self')</script>";
    }

}
else {
    echo"<script>window.open('../login.php', '_self')</script>";
}

?>