function viewProfile() {
    var ID = getCookie('userID');
    if (ID.length == 0) {
        window.open("login.php", "_self");
    } else {
        window.open("profile.php", "_self");
    }
}

function cart() {
    var userID = getCookie('userID');
    if (userID.length == 0) {
        window.open("login.php", "_self");
    }
    else {
        window.open("cart.php", "_self");
    }
}