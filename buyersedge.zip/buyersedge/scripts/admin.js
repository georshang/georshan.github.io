/* Products Manage functions  */
function deleteItem(productID) {
    $(".products-list").load('../php/admin-delete-product.php', {
        productID: productID,
    });
}

function loadfile(event) {
    var output = document.getElementById('img-preview');
    output.src = URL.createObjectURL(event.target.files[0]);
}


/* Users Manage functions  */
function deleteUser(userID) {
    $(".users-container").load('../php/admin-delete-user.php', {
        userID: '\"'+userID+'\"',
    });
}


/* orders Manage functions  */
function manageOrder(orderCommand, orderID, data) {
    $(".orders-container").load('../php/admin-order-process.php', {
        orderID: orderID,
        orderCommand: orderCommand,
        data: data,
    });
}

function viewUsers(a){
    if(!a){
        i = 0;
        a = i;
    }
    var url = "../admin/manage-users.php?data="+a;
    window.open(url, "_self");
    
}

function viewOtherOrders(a){
    if(!a){
        i = 0;
        a = i;
    }
    var url = "../admin/manage-orders.php?data="+a;
    window.open(url, "_self");
    
}

function manageProducts(a){
    if(!a){
        i = 0;
        a = i;
    }
    var url = "../admin/manage-products.php?data="+a;
    window.open(url, "_self");
    
}


function new_category(){
    var data = "<input type='text' name='category'>";
    document.getElementById('new_category').innerHTML=data;
}

function editUsers(userID){
    
    var url ='../php/admin_user_access.php?user_ID='+userID;
    window.open(url,"_self");
}

